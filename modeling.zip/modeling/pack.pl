name(modeling).
title('Constraint-based mathematical modeling library for Prolog.').
version('1.0').
author('Francois Fages', 'Francois.Fages@inria.fr').
home('https://lifeware.inria.fr/wiki/Main/Software#modeling').
download('https://lifeware.inria.fr/~fages/modeling.zip').
%download('https://github.com/FFages/modeling/modeling.zip').


