/*
  quantifiers.pl
  
  @author Francois Fages
  @email Francois.Fages@inria.fr
  @license LGPL-2

  Quantifiers and let expressions.
  
*/


:- module(
	  quantifiers,
	  [
	   for_all/2,
	   exists/2,
	   let/2,

	   list_of/2,

	   apply_list/2,
	   call_list/2,
	   call_list/3,
	   call_list/4,
	   call_list/5,
	   call_list/6,
	   
	   op(501, xfx, ..),
	   op(502, yfx, \/),
	   
	   op(700, xfx, in),
	   op(990, xfx, where)
	  ]).

/** <module> Quantifiers and let expressions.

  for_all/2 bounded universal quantifier with in/2 and where/2 conditions.

  list_of/2 list of values satisfying in/2 and where/2 conditions.

  exists/2 and let/2 existential quantifier allowing functional notations (e.g. for array cells) in expressions.

  apply_list/2, call_list/2,3,4,5 conjunctive application of a goal

==

?- for_all(I in 1..3, J #> I).
clpfd:(J in 4..sup).

?- for_all(I in 1..3, J #= I+1).
false.

?- exists([I], (I=2, J #= I+1)).
J = 3.

?- let([I=2], J #= I+1).
J = 3.

==
  
*/
				% CONJUNCTIVE APPLICATION OF A GOAL

:- meta_predicate apply_list(1, ?).

%! apply_list(+Goal, +ArgsList)
%
% Conjunctive application of Goal to list ArgsList of arguments. Fails if the conjunction is not satisfiable.

apply_list(Goal, ArgsList):-
    list_apply(ArgsList, Goal).

list_apply([], _).
list_apply([Args | ArgsList], Goal):-
    apply(Goal, Args),
    list_apply(ArgsList, Goal).


:- meta_predicate call_list(1, ?).
:- meta_predicate call_list(2, ?, ?).
:- meta_predicate call_list(3, ?, ?, ?).

:- meta_predicate list_call(?, 1).
:- meta_predicate list_call(?, ?, 2).
:- meta_predicate list_call(?, ?, ?, 3).

%! call_list(+Goal, ?Args)
%
% More efficient conjunctive application of a one argument Goal to list Args of arguments.

call_list(Goal, Args1):-
    list_call(Args1, Goal).

list_call([], _).
list_call([Arg1 | Args1], Goal):-
    call(Goal, Arg1),
    list_call(Args1, Goal).


%! call_list(+Goal, ?Args1, ?Args2)
%
% Conjunctive application of Goal to list of arguments Args1, Args2, ...

call_list(Goal, Args1, Args2):-
    list_call(Args1, Args2, Goal).

list_call([], [], _).
list_call([Arg1 | Args1], [Arg2 | Args2], Goal):-
    call(Goal, Arg1, Arg2),
    list_call(Args1, Args2, Goal).



call_list(Goal, Args1, Args2, Args3):-
    list_call(Args1, Args2, Args3, Goal).

list_call([], [], [], _).
list_call([Arg1 | Args1], [Arg2 | Args2], [Arg3 | Args3], Goal):-
    call(Goal, Arg1, Arg2, Arg3),
    list_call(Args1, Args2, Args3, Goal).


call_list(Goal, Args1, Args2, Args3, Args4):-
    list_call(Args1, Args2, Args3, Args4, Goal).

list_call([], [], [], [], _).
list_call([Arg1 | Args1], [Arg2 | Args2], [Arg3 | Args3], [Arg4 | Args4], Goal):-
    call(Goal, Arg1, Arg2, Arg3, Arg4),
    list_call(Args1, Args2, Args3, Args4, Goal).


call_list(Goal, Args1, Args2, Args3, Args4, Args5):-
    list_call(Args1, Args2, Args3, Args4, Args5, Goal).

list_call([], [], [], [], [], _).
list_call([Arg1 | Args1], [Arg2 | Args2], [Arg3 | Args3], [Arg4 | Args4], [Arg5 | Args5], Goal):-
    call(Goal, Arg1, Arg2, Arg3, Arg4, Arg5),
    list_call(Args1, Args2, Args3, Args4, Args5, Goal).



				% BOUNDED UNIVERSAL QUANTIFIER

/* PROBLEM INCOMPLETE INSTANCIATION WITH NON-DETERMINISTIC CONDITIONS

==
?- L=[_, _], L ins 1..3, for_all(U in 0..5 where exists(V, (member(V, L), U#=V+1)), writeln(U)).
2
3
L = [1, 2] ;
2
3
L = [2, 1] ;
false.

?- forall(member(I,[1,2,3]), (V is I+1, writeln(V))).
2
3
4
true.

?- foreach(member(I,[1,2,3]), (V is I+1, writeln(V))).
2
false.

==

*/

%! for_all(+Domains, +Goal)		  
% 
% universally quantified Goal satisfied for all variables values in Domains specified with in and where/2 conditions.
% for_all/2 is non-deterministic if either the Goal or a where/2 condition is non-deterministic.


for_all(Domains, _Goal):-
    must_be(nonvar,Domains), %TODO for universal variable
    fail.

for_all(Domains where _Condition, _Goal) :-
    must_be(nonvar, Domains),
    fail.

for_all(Vars in Domain where Condition, Goal):-
    !,
    (var(Vars)
    ->
     for_list([Vars in  Domain], [], [], Condition, Goal)
    ;
     Vars=[]
    ->
     true
    ;
     distribute(Vars, Domain, Domains),
     for_list(Domains, [], [], Condition, Goal)).

for_all(Domains where Condition, Goal) :-
    !,
    (Domains=[]
    ->
     true
    ;
     for_list(Domains, [], [], Condition, Goal)).

for_all(Vars in Domain, Goal):-
    !,
    for_all(Vars in Domain where true, Goal).

for_all(Domains, Goal):-
    for_all(Domains where true, Goal).



distribute([], _, []).
distribute([Var | Vars], Domain, [Var in Domain | Domains]):-
    distribute(Vars, Domain, Domains).


% Conditions creating non-deterministic constraints in the context variables should make for_all metapredicate non-determinisitc.
% TODO this is not correctly handled now.

% for_list([], Vars, Values, Condition, Goal):-
%     copy_term(Vars, Condition, Values, Cond),
%     gensym(for_list, Key),
%     nb_setval(Key, false),
%     ((Cond,			% backtrackable condition
%       nb_setval(Key, true),
%       copy_term(Vars, Goal, Values, G),
%       G				% backtrackable goal
%      )
%     ;
%      nb_getval(Key, false)    % PROBLEM keeps a choice point on successes
%      ).

% Problem on non-deterministic conditions
% ?- for_all(I in 1..3 where X=I, true).
% X = 1.
%
for_list([], Vars, Values, Condition, _Goal):-
    copy_term(Vars, Condition, Values, Cond),
    \+ Cond,			% PROBLEM executed twice in case of success
    !.
for_list([], Vars, Values, Condition, Goal):-
    copy_term(Vars, Condition, Values, Cond),
    Cond,			% backtrackable condition
    copy_term(Vars, Goal, Values, G),
    G.				% backtrackable goal

for_list([D | Domains], Vars, Values, Condition, Goal):-
    must_be(nonvar, D),
    D = (V in Domain),
    (next_value(Domain, Min, Greater)
    ->
     Vs = [V | Vars],
     Vals = [Min | Values],
     copy_term(Vs, Domains, Vals, Doms),
     for_list(Doms, Vs, Vals, Condition, Goal),
     (Greater=[]
     ->
      true
     ;
      for_list([V in Greater | Domains], Vars, Values, Condition, Goal))
    ;
     true). % V has an empty domain


next_value(Min .. Max, Mi, Greater):-
    Mi is Min, % TODO array expressions in domains 
    Ma is Max,
    (Mi < Ma
    ->
     Mi1 is Mi+1,
     Greater = Mi1..Ma
    ;
     Mi = Ma, % otherwise fail, empty domain
     Greater = []).

next_value(Domain1 \/ Domain2, Min, Greater):-
    nextvalue(Domain1, Min, Great),
    (Great = []
    ->
     Greater = Domain2
    ;
     Greater = Great \/ Domain2).

next_value([Min | List], Mi, List):-
    catch(Mi is Min, _, Mi=Min).


				% EXISTENTIAL QUANTIFIER AND LET EXPRESSIONS

%! exists(+Vars, +Goal)
%
% calls Goal with existentizlly quantified variables Vars.

exists(Vars, Goal):- 
    copy_term(Vars, Goal, _, RenamedGoal),
    RenamedGoal.


%! let(+Bindings, +Goal)
%
% calls Goal with existentially quantified variable Bindings given with expressions allowing array notations.

let(Bindings, Goal):-
    (bindings(Bindings, Vars, Goals)
    ->
     copy_term(Vars, (Goals, Goal), _, RenamedGoal),
     RenamedGoal
    ;
     throw(error(instantiated_variable_in(for_all, let(Bindings, Goal))))).    


%! bindings(+Bindings, ?Vars, ?Goal)
% 
%  returns the list Vars of existentially quantified variables Vars and the Goal to execute for their binding.

bindings([], [], true).
    
bindings([Binding | Bindings], [X|ExistsVars], Goal):-
    (var(Binding)
    ->
     % just a way to use let/2 for existentially quantified variables as in exists/2
     X=Binding,
     bindings(Bindings, ExistsVars, Goal)
    ;
     Binding =.. [Binder, X, Expr],
     member(Binder, [=, =.., in, ins, #=, #<, #>, #=<, #>=, #\=]), % whatever makes sense for a let
     var(X),
     (var(Expr)
     ->
      Xgoal = Binding
     ;
      expand_term(Binding, Xgoal)
     ->
      true
     ;
      Xgoal=Binding),
     Goal=(Xgoal, Goals),
     bindings(Bindings, ExistsVars, Goals)).



				% LIST OF INSTANCES DEFINED BY IN/2 AND WHERE/2 TERMS


/* PROBLEM INCOMPLETE INSTANCIATIONS WITH NON-DETERMINSTIC CONDITIONS

==
?- L=[X, Y], L ins 1..3, list_of(U in 0..5 where exists(V, (member(V, L), U#=V+1)), R).
L = [1, 2],
X = 1,
Y = 2,
R = [2, 3] ;
L = [2, 1],
X = 2,
Y = 1,
R = [2, 3] ;
false.

=

*/

%! list_of(+Domains, ?Values)
%
% Values is the list of tuple values that are in Domains with in and where conditions.

list_of(Var, [Var]):-
    var(Var),
    !.

list_of(Vars in Domain where Condition, List):-
    !,
    (var(Vars)
    ->
     list_list([Vars in  Domain], [], [], Condition, List)
    ;
     Vars=[]
    ->
     true
    ;
     distribute(Vars, Domain, Domains),
     list_list(Domains, [], [], Condition, List)).

list_of(Vars in Domain, List):-
    !,
    list_of(Vars in Domain where true, List).


list_of(Domains where Condition, List) :-
    !,
    must_be(nonvar, Domains),
    (Domains=[]
    ->
     true
    ;
     list_list(Domains, [], [], Condition, List)).

list_of(Domains, List):-
    list_of(Domains where true, List).



% list_list([], Vars, Values, Condition, List):-
%     copy_term(Vars, Condition, Values, Cond),
%     gensym(list_list, Key),
%     nb_setval(Key, false),
%     ((Cond,			% backtrackable condition
%       nb_setval(Key, true),
%       List=Values
%      )
%     ;
%      nb_getval(Key, false),
%      List=[]
%     ).

list_list([], Vars, Values, Condition, []):-
    copy_term(Vars, Condition, Values, Cond),
    \+ Cond,			% PROBLEM executed twice in case of success
    !.

list_list([], Vars, Values, Condition, List):-
    copy_term(Vars, Condition, Values, Cond),
    Cond,			% backtrackable condition
    List=Values.

list_list([D | Domains], Vars, Values, Condition, List):-
    must_be(nonvar, D),
    D = (V in Domain),
    (next_value(Domain, Min, Greater)
    ->
     Vs = [V | Vars],
     Vals = [Min | Values],
     copy_term(Vs, Domains, Vals, Doms),
     list_list(Doms, Vs, Vals, Condition, List1), % for append !
     (Greater=[]
     ->
      List = List1
     ;
      list_list([V in Greater | Domains], Vars, Values, Condition, List2),
      append(List1, List2, List))
    ;
     List = []). 

    

:- multifile expand_term/2.

%! expand_term(+Term, ?Expansion)
%
% Multifile predicate defining Term Expansion allowed in let expressions.
% Defined here for the conditional expression if/3  (TODO generalization to deep expressions ?)
% and in module arrays.pl for the Array[Indices] notation.

expand_term(X=if(Condition, V1, V2), (Condition -> X=V1 ; X=V2)):-
    !.

