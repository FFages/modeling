/*
  examples.pl
  
  @author Francois Fages
  @email Francois.Fages@inria.fr
  @institute Inria, France
  @license LGPL-2

  @version 1.0

  

*/

:- module(modeling,
	  [
	   queens/2,
	   queens_distinct/2,
	   queens_sym/2,
	   sym_elim/2,
	   queens_sym_distinct/2,

	   queens_list/2,
	   queens_distinct_list/2,
	   queens_sym_list/2,
	   sym_elim_list/2,
	   queens_sym_distinct_list/2,

	   show/2,

	   fourier/4,

	   benchmark/0
	   ]).


/** <module> examplesFLOPS2024

  Examples of use of SWI-Prolog pack modeling described in

  F. Fages. A Constraint-based Mathematical Modeling Library in Prolog with Answer Constraint Semantics.
  17th International Symposium on Functional and Logic Programming, FLOPS 2024.
  May 15, 2024 - May 17, 2024, Kumamoto, Japan. LNCS, Springer-Verlag.
 

==
?- queens(8,Queens), show(Queens).
Q . . . . . . .
. . . . . . Q .
. . . . Q . . .
. . . . . . . Q
. Q . . . . . .
. . . Q . . . .
. . . . . Q . .
. . Q . . . . .

Queens = array(1, 5, 8, 6, 3, 7, 2, 4) .

?- fourier(3, X, Y, 1).
X = Y, Y = 6.666666666666667.

?- fourier(3.1, X, Y, 1).
false.

?- fourier(2, X, Y, 1).
{Y=20.0-10.0*_A-10.0*_B, X=10.0*_B, _=2.0-_A-_B, _A+_B>=1.0, _B=<1.0, _A=<1.0}.

?- fourier(0, X, Y, 1).
true.
  
?- fourier(2, X, Y, 1), minimize(X).
X = 0.0,
Y = 10.0.

?- fourier(2, X, Y, 1), maximize(X).
X = 10.0,
{Y=10.0-10.0*_A, _=1.0-_A, _A=<1.0, _A>=0.0}.

?- fourier(2, X, Y, 1), maximize(Y).
Y = 10.0,
{X=10.0*_A, _A>=0.0, _A=<1.0, _=1.0-_A}.

?- fourier(2, X, Y, 1), minimize(Y).
X = 10.0,
Y = 0.0.
==
*/

:- use_module(modeling).

				% N-QUEENS PLACEMENT MODELS USING SUBSCRIPTED VARIABLES


%! queens(+N, ?Queens)
%
% solves the N Queens problems using arrays.

queens(N, Queens):-
  int_array(Queens, [N], 1..N),
  for_all([I in 1..N-1, D in 1..N-I],
          (Queens[I] #\= Queens[I+D],
           Queens[I] #\= Queens[I+D]+D,
           Queens[I] #\= Queens[I+D]-D)),
  satisfy(Queens).



%! queens_distinct(+N, ?Queens)
%
% solves the N Queens problems using arrays and the global constraint all_distinct/1 of library(clpfd)

queens_distinct(N, Queens):-
    int_array(Queens, [N], 1..N),
    
    int_array(Indices, [N]),
    for_all(I in 1..N, cell(Indices, I, I)),
    
    tensor(Queens, +, Indices, #=, QueensPlusI), 
    tensor(Queens, -, Indices, #=, QueensMinusI),

    all_distinct(QueensPlusI),
    all_distinct(Queens),
    all_distinct(QueensMinusI),

    satisfy(Queens).


%! queens_sym(+N, ?Queens)
%
% solves the N Queens problems with symmetry breaking using arrays.

queens_sym(N, Queens):-
  int_array(Queens, [N], 1..N),
  for_all([I in 1..N-1, D in 1..N-I],
          (Queens[I] #\= Queens[I+D],
           Queens[I] #\= Queens[I+D]+D,
           Queens[I] #\= Queens[I+D]-D)),
  sym_elim(N, Queens),
  satisfy(Queens).


sym_elim(N, Queens) :-
  
  Queens[1] #< Queens[N], % vertical reflection
  Queens[1] #=< (N+1)//2, % horizontal reflection
  
  int_array(Dual, [N], 1..N), 
  for_all([I, J] in 1..N, Queens[I] #= J #<==> Dual[J] #= I),
  lex_leq(Queens, Dual),  % first diagonal reflection
  
  int_array(SecondDiagonal, [N], 1..N),
  for_all(I in 1..N, SecondDiagonal[I] #= N + 1 - Dual[N+1-I]),
  lex_leq(Queens, SecondDiagonal), 

  int_array(R90, [N], 1..N),
  for_all(I in 1..N, R90[I] #= Dual[N+1-I]),
  lex_leq(Queens, R90),   % rotation 90°

  int_array(R180, [N], 1..N),
  for_all(I in 1..N, R180[I] #= N + 1 - Queens[N+1-I]),
  lex_leq(Queens, R180),
  
  int_array(R270, [N], 1..N),
  for_all(I in 1..N, R270[I] #= N + 1 - Dual[I]),
  lex_leq(Queens, R270).



%! queens_sym_distinct(+N, ?Queens)
%
%  solves the N Queens problems with symmetry breaking using arrays and global constraint all_distinct/1.

queens_sym_distinct(N, Queens):-
    int_array(Queens, [N], 1..N),
    int_array(Indices, [N]),
    for_all(I in 1..N, cell(Indices, I, I)),
    tensor(Queens, +, Indices, #=, QueensPlusI), 
    tensor(Queens, -, Indices, #=, QueensMinusI),
    all_distinct(QueensPlusI),
    all_distinct(Queens),
    all_distinct(QueensMinusI),
    
    sym_elim(N, Queens),
    
    satisfy(Queens).


				% N-QUEENS PLACEMENT PROGRAMS USING LISTS


%! queens_list(+N, ?Queens)
%
% standard program using lists for the N Queens problem.

queens_list(N, Queens):-
  length(Queens, N),
  Queens ins 1..N,
  safe(Queens),
  labeling([ff], Queens).

safe([]).
safe([QI | Tail]) :-
  noattack(Tail, QI, 1),
  safe(Tail).

noattack([], _, _).
noattack([QJ | Tail], QI, D) :-
  QI #\= QJ,
  QI #\= QJ + D,
  QI #\= QJ - D,
  D1 #= D + 1,
  noattack(Tail, QI, D1).


%! queens_distinct_list(+N, ?Queens)
%
% program using lists and the global constraint all_distinct/1 of library(clpfd)

queens_distinct_list(N, Queens):-
    length(Queens, N),
    Queens ins 1..N,

    length(Indices, N),
    for_all(I in 1..N, nth1(I, Indices, I)),
    
    tensor(Queens, +, Indices, #=, QueensPlusI), 
    tensor(Queens, -, Indices, #=, QueensMinusI),

    all_distinct(QueensPlusI),
    all_distinct(Queens),
    all_distinct(QueensMinusI),

    labeling([ff], Queens).


%! queens_sym_list(+N, ?Queens)
%
% list program to break symmetries in the N Queens problem.

queens_sym_list(N, Queens) :- 
  length(Queens, N),
  Queens ins 1..N,
  safe(Queens),

  sym_elim_list(N, Queens),

  labeling([ff], Queens).


sym_elim_list(N, Queens) :-
  last(Queens, Last),
  Queens = [First | _],
  First #< Last,
  First #=< (N+1) // 2,

  dual(N, Queens, Dual),
  lex_leq(Queens, Dual),

  length(CounterDiagonal, N),
  reverse(Dual, DualReversed),	% in order N+1-I
  counterdiag(CounterDiagonal, 1, N, DualReversed),
  lex_leq(Queens, CounterDiagonal),

  length(R90, N),
  r90(R90, 1, N, DualReversed),
  lex_leq(Queens, R90),
  
  length(R180, N),
  reverse(Queens, QueensReversed), % in order N+1-I
  r180(R180, 1, N, QueensReversed),
  lex_leq(Queens, R180),
  
  length(R270, N),
  r180(R270, 1, N, Dual), % not a typo ! since applied here to the dual instead of the reversed primal
  lex_leq(Queens, R270).


dual(N, Queens, Dual):-
    length(Dual, N),
    forall_IJ(Queens, 1, Dual).

forall_IJ([],  _, _).
forall_IJ([QI |Qs], I, Dual):-
    forall_J(Dual, 1, QI, I),
    I1 #= I+1,
    forall_IJ(Qs, I1, Dual).

forall_J([], _, _,  _).
forall_J([RJ | R], J, QI, I):-
    (QI#=J) #<==> (RJ#=I),
    J1 #= J+1,
    forall_J(R, J1, QI, I).

counterdiag([], _, _, _).
counterdiag([CI | CounterDiagonal], I, N, [DI | Dual]):-
    CI #= N+1-DI,
    I1 is I+1,
    counterdiag(CounterDiagonal, I1, N, Dual).

r90([], _, _, _).
r90([RI | R90], I, N, [DI | Dual]):-
    RI #= DI,
    I1 is I+1,
    r90(R90, I1, N, Dual).

r180([], _, _, _).
r180([RI | R90], I, N, [DI | Dual]):-
    RI #= N+1-DI,
    I1 is I+1,
    r180(R90, I1, N, Dual).


%! queens_sym_distinct_list(+N, ?Queens)
%
% list program with symmetry breaking and global constraint all_distinct/2

queens_sym_distinct_list(N, Queens) :- 
    length(Queens, N),
    Queens ins 1..N,
    
    length(Indices, N),
    for_all(I in 1..N, nth1(I, Indices, I)),
    
    tensor(Queens, +, Indices, #=, QueensPlusI), 
    tensor(Queens, -, Indices, #=, QueensMinusI),
    
    all_distinct(QueensPlusI),
    all_distinct(Queens),
    all_distinct(QueensMinusI),

    sym_elim_list(N, Queens),
    
    labeling([ff], Queens).


				% PRETTY-PRINT OF THE CHESSBOARD PLACEMENT


%! show(+Queens)
%
% pretty prints chessboard Queens (either array or list).

show(Queens):-
    (array(Queens)
    ->
     show_array(Queens)
    ;
     show_list(Queens)).

show_array(Queens):-
    array(Queens, [N]),
    for_all([I, J] in 1..N,
    	    let([QJ = Queens[J],
    		 Q = if(QJ = I, 'Q', '.'),
    		 B = if(J = N, '\n', ' ')],
		format("~w~w",[Q,B]))),
    nl.

show_list(Queens):-
    length(Queens, N),
    for_all([I, J] in 1..N,
	    exists(QJ,
		   (nth1(J, Queens, QJ),
		    let([Q = if(QJ = I, 'Q', '.'),
			 B = if(J = N, '\n', ' ')],
			format("~w~w",[Q,B]))))),
    nl.


				% BENCHMARKING
/*
  ?- benchmark.
user:queens(100,_69028)
% 4,552,518 inferences, 0.373 CPU in 0.387 seconds (96% CPU, 12212181 Lips)
user:queens_list(100,_2790392)
% 4,472,406 inferences, 0.298 CPU in 0.310 seconds (96% CPU, 15025469 Lips)
user:queens_distinct(100,_8210576)
% 63,565,626 inferences, 3.611 CPU in 3.641 seconds (99% CPU, 17603740 Lips)
user:queens_distinct_list(100,_1467832)
% 63,502,308 inferences, 3.470 CPU in 3.484 seconds (100% CPU, 18298489 Lips)
user:(queens(8,_1913650),fail)
% 757,835 inferences, 0.041 CPU in 0.041 seconds (99% CPU, 18435668 Lips)
user:(queens_list(8,_1914304),fail)
% 757,303 inferences, 0.042 CPU in 0.043 seconds (99% CPU, 17926877 Lips)
user:(queens_distinct(8,_1914958),fail)
% 4,025,643 inferences, 0.297 CPU in 0.303 seconds (98% CPU, 13541040 Lips)
user:(queens_distinct_list(8,_79224),fail)
% 4,012,622 inferences, 0.289 CPU in 0.295 seconds (98% CPU, 13908424 Lips)
user:(queens_sym(8,_33346),fail)
% 667,850 inferences, 0.045 CPU in 0.046 seconds (98% CPU, 14860595 Lips)
user:(queens_sym_list(8,_34000),fail)
% 664,708 inferences, 0.048 CPU in 0.049 seconds (97% CPU, 13812975 Lips)
user:(queens_sym_distinct(8,_34654),fail)
% 1,471,542 inferences, 0.125 CPU in 0.132 seconds (95% CPU, 11760763 Lips)
user:(queens_sym_distinct_list(8,_34510),fail)
% 1,509,989 inferences, 0.128 CPU in 0.132 seconds (97% CPU, 11818117 Lips)
true.
*/

benchmark :-
    % first solution
    test(queens(100, _)),
    test(queens_list(100, _)),
    test(queens_distinct(100, _)),
    test(queens_distinct_list(100, _)),
    % all solutions
    test((queens(8, _), fail)),
    test((queens_list(8, _), fail)),
    test((queens_distinct(8, _), fail)),
    test((queens_distinct_list(8, _), fail)),
    % non symmetrical solutions
    test((queens_sym(8, _), fail)),
    test((queens_sym_list(8, _), fail)),
    test((queens_sym_distinct(8, _), fail)),
    test((queens_sym_distinct_list(8, _), fail)),
    % clpr interface
    test(fourier(2, _, _, 1)).


test(Goal):-
    writeln(Goal),
    (time(Goal) -> true ; true).




				% FOURIER'S EXAMPLE OVER THE REAL NUMBERS


%! fourier(?P, ?X, ?Y, ?F)
%
% Placing a weight P at coordinates X Y on an isocel triangle table with 3 legs at coordinates (0,0), (20, 0) and (0, 20)
% and with a maximum force F exerted on each leg.

fourier(P, X, Y, F):-
    float_array(Force, [3], 0..F),
    {Force[1]+Force[2]+Force[3] = P,
     P*X = 20*Force[2],
     P*Y = 20*Force[3]}.

