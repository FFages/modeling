/*
  modeling.pl
  
  @author Francois Fages
  @email Francois.Fages@inria.fr
  @institute Inria, France
  @license LGPL-2

  @version 1.0

*/

:- module(
	  modeling,
	  [
	   int_array/2,
	   int_array/3,
	   bool_array/2,
	   float_array/2,
	   float_array/3,
	   satisfy/1,
	   satisfy/2,
	   satisfy_attvars/1,
	   satisfy_attvars/2,
	   minimize/2,
	   minimize/3,
	   maximize/2,
	   maximize/3
	  ]
	 ).

/** <module> Constraint-based mathematical modeling.

  This module provides a constraint-based mathematical modeling language in the spirit of MiniZinc in Prolog.
  (A MiniZinc parser and connection to the visualization and interaction tool CLPGUI are planned to be added to this library in a next release).
  
  The pack includes modules arrays.pl, quantifiers.pl and clp.pl.

  Module clp.pl is a patch of library(clpr) and library(clpfd) to allow array functional notations Array[Indices] in constraints and let/2
  and evaluable expressions in domain declarations.

  This makes it possible to express constraints on multi-dimensional arrays of integers, booleans, real numbers or terms,
  using general-purpose quantifiers for_all/2, exists/2, let/2, and domain predicates in/2, where/2.

  The variables under a let/2 are existentially quantified as by exists/2.
  The conditional expression if/3 is also allowed in let/2 bindings.
  It worth noting that it is essential to distinguish between the existentially quantified variables which are local to a goal
  and the other variables which are shared with the context.

  Below is the example of a goal that can be written in this library to solve the 8-queens placement problem and pretty-print the chessboard
  
==
?- N=8,
  int_array(Queens, [N], 1..N),
  
  for_all([I in 1..N-1, D in 1..N-I],
      (Queens[I] #\= Queens[I+D],
       Queens[I] #\= Queens[I+D]+D,
       Queens[I] #\= Queens[I+D]-D)),
  
  satisfy(Queens),
  
  for_all([I, J] in 1..N,
      let([QJ = Queens[J],
           Q = if(QJ = I, 'Q', '.'),
           B = if(J = N, '\n', ' ')],
          format("~w~w",[Q,B]))).
  
Q . . . . . . .
. . . . . . Q .
. . . . Q . . .
. . . . . . . Q
. Q . . . . . .
. . . Q . . . .
. . . . . Q . .
. . Q . . . . .
  
N = 8,
Queens = array(1, 5, 8, 6, 3, 7, 2, 4) ;
  
Q . . . . . . .
. . . . . . Q .
. . . Q . . . .
. . . . . Q . .
. . . . . . . Q
. Q . . . . . .
. . . . Q . . .
. . Q . . . . .
  
N = 8,
Queens = array(1, 6, 8, 3, 7, 4, 2, 5) .

==

  The file examples.pl defines a predicate elim_sym/2 to solve this problem by eliminating all isometries of the chessboard square
  in a declarative way using iteration on subscripted variables rather than list recursion.

  It also contains an example from Fourier using constraint over the real numbers :

==
?- listing(fourier/4).
fourier(P, X, Y, M) :-
    float_array(Forces, [3], 0..M),
    { Forces[1]+Forces[2]+Forces[3]=P,
      P*X=20*Forces[2],
      P*Y=20*Forces[3]
    }.

true.

?- fourier(3, X, Y, 1).
X = Y, Y = 6.666666666666667.

?- fourier(3.1, X, Y, 1).
false.

?- fourier(2, X, Y, 1).
{Y=20.0-10.0*_A-10.0*_B, X=10.0*_B, _=2.0-_A-_B, _A+_B>=1.0, _B=<1.0, _A=<1.0}.

?- fourier(2, X, Y, M), minimize(M).
X = 6.666666666666667,
Y = 6.666666666666666,
M = 0.6666666666666667.

?- fourier(2, X, Y, M).
{Y=10.0*_A, X=10.0+5.0*_B+5.0*_C-5.0*_A, _A>=0.0, _= -1.0- ... * ... + 0.5*_C+1.5*_A, _B-_C-3.0*_A>= -2.0, _= ... + ... - ... * ..., ... - ... >= -2.0, ... =< ..., ..., ...}.
==

*/

:- op(990, xfx, where).
:- op(100, yf, []).

% Pb with pldoc if in front

:- use_module(clp).


%! bool_array(?Array, ?IndexList)
% 
% Array is a array of Boolean values (0 or 1) or Boolean variables of dimensions IndexList.

bool_array(Array, IndexList):-
    int_array(Array, IndexList, 0..1).


%! int_array(?Array, ?IndexList)
% 
% Array is an array of integer numbers or variables of dimensions IndexList.

int_array(Array, IndexList):-
    int_array(Array, IndexList, inf..sup).


%! int_array(?Array, ?IndexList, +Range)
% 
% Array is an array of integer numbers or variables in Range of dimensions IndexList.

int_array(Array, IndexList, Range):-
    array(Array, IndexList),
    array_list(Array, List),
    (
     var(Range)
    ->
     for_all([Cell in List],
	     exists([Mi, Ma], (fd_inf(Cell, Mi), Min #=< Mi, fd_sup(Cell, Ma), Ma #=< Max))),
     fd_sup(Min, Inf),
     fd_inf(Max, Sup),
     Range = Inf .. Sup
    ;
     List ins Range
    ).

    
%! float_array(?Array, ?IndexList)
% 
% Array is an array of real numbers or variables of dimensions IndexList.
% TODO find a way to mark it as an array of real variables 

float_array(Array, IndexList):-
    array(Array, IndexList).


%! float_array(?Array, ?IndexList, +Range)
% 
% Array is an array of real numbers or variables in Range Min..Max of dimensions IndexList.
% If not given the Range variables are returned with constraints, or fails if they are unbounded.
% CHANGED FROM returned is the minimum and maximum current values. The predicate fails if they are unbounded.

float_array(Array, IndexList, Min..Max):-
    array(Array, IndexList),
    array_list(Array, List),
    for_all([Cell in List], {Min=< Cell, Cell =< Max}).
    %sup(Min, Min),
    %inf(Max, Max).


%! satisfy(+Term)
% 
% enumerate all solutions of the variables contained or related to Term.

satisfy(Term):-
    satisfy(Term, [ff]).


%! satisfy(+Term, +Options)
% 
% same as satisfy/1 with the Options from library(clpfd) predicate labeling/2.

satisfy(Term, Options) :-
    term_variables(Term, Vars),
    labeling(Options, Vars).

   
%! satisfy_attvars(+Term)
% 
% same as satisfy/1 but enumerating also the values of the variables contained in the attributes of the variables in Term.

satisfy_attvars(Term):-
    satisfy_attvars(Term, [ff]).

    
%! satisfy_attvars(+Term, +Options)
% 
% same as satisfy/2 but enumerating also the values of the variables contained in the attributes of the variables in Term.

satisfy_attvars(Term, Options) :-
    term_attvars(Term, Vars),
    labeling(Options, Vars).


   
%! minimize(+Expr, +Term)
% 
% enumerate all solutions of the variables contained in Term in increasing order of Expr.

minimize(Expr, Term):-
    term_attvars(Term, Vars),
    labeling([min(Expr), ff], Vars).


%! minimize(+Expr, +Term, +Options)
% 
% same as minimize/2 using extra library(clpfd) labeling/2 options
minimize(Expr, Term, Options):-
    term_attvars(Term, Vars),
    labeling([min(Expr) | Options], Vars).

   
%! maximize(+Expr, +Term)
% 
% enumerate all solutions of the variables contained in Term in decreasing order of Expr.

maximize(Expr, Term):-
    term_attvars(Term, Vars),
    labeling([max(Expr), ff], Vars).

%! maximize(+Expr, +Term, +Options)
% 
% same as maximize/2 using extra library(clpfd) labeling/2 options

maximize(Expr, Term, Options):-
    term_attvars(Term, Vars),
    labeling([max(Expr) | Options], Vars).


% reexport at the end for better pldoc ordering of the predicates
:- reexport([clp]).
