/*
  clp.pl
  
  @author Francois Fages
  @email Francois.Fages@inria.fr
  @license LGPL-2

  Patch to library(clpr) and library(clpfd) to allow evaluable arithmetic expressions and array notations in domains and constraints.

  Additional patch to library(clpfd) to avoid the duplication of constraint propagator when unifying two clpfd variables.

  Extra of constraints lex_leq/2, lex_lt/2, minimum/2, maximum/2.

*/

:- module(clp, [
		lex_leq/2,
		lex_lt/2,
		minimum/2,
		maximum/2,
				%CLPFD
                in/2,
                ins/2,
		(#>)/2,
		(#<)/2,
		(#>=)/2,
		(#=<)/2,
		(#=)/2,
		(#\=)/2,
		(#\)/1,
		(#<==>)/2,
		(#==>)/2,
		(#<==)/2,
		(#\/)/2,
		(#\)/2,
		(#/\)/2,
		
		all_different/1,
		all_distinct/1,
		sum/3,
		scalar_product/4,
		tuples_in/2,
		labeling/2,
		label/1,
		lex_chain/1,
		serialized/2,
		global_cardinality/2,
		global_cardinality/3,
		circuit/1,
		cumulative/1,
		cumulative/2,
		disjoint2/1,
		element/3,
		automaton/3,
		transpose/2,
		chain/2,

		%op(450, xfx, ..), % in clpfd: "should bind more tightly than \/ of priority 500"
		op(501, xfx, ..), % but here less tightly than arithmetic expressions where * has priority 500
		op(502, yfx, \/), % consequently changed from 500 to 502 WITH ONE RISK FOR BITWISE OR 

		op(760, yfx, #<==>),
		op(750, xfy, #==>),
		op(750, yfx, #<==),
		op(740, yfx, #\/),
		op(730, yfx, #\),
		op(720, yfx, #/\),
		op(710,  fy, #\),
		op(700, xfx, #>),
		op(700, xfx, #<),
		op(700, xfx, #>=),
		op(700, xfx, #=<),
		op(700, xfx, #=),
		op(700, xfx, #\=),
		op(700, xfx, in), 
		op(700, xfx, ins),

				%CLPR
		
		{}/1,
		entailed/1,
		maximize/1,
		minimize/1,
		inf/2,
		sup/2, 
		bb_inf/3,
		bb_inf/4,
		bb_inf/5,


				% ARRAYS
		
		op(100, yf, []) % for array cell notation Array[Indices]
		]).

/** <module> constraint-based modeling 

  Patch of library(clpr) and library(clpfd) to allow evaluable arithmetic expressions and array notations in domains and constraints.

  Additional patch in library(clpfd) to avoid the duplication of constraint propagator when unifying two clpfd variables.

  Extra of constraints lex_leq/2, lex_lt/2, minimum/2, maximum/2.
  
  The patch to library(clpfd)  adds two new features:

    * allowing array notations in constraints and evaluable arithmetic expressions in domain definitions
  (with a slight change of operator priority from 450 to op(501, xfx, ..) op(502, yfx, \/) which may cause a priority problem on bitwise shift operation)

==
?- A=array(X,Y,Z), all_distinct([A[1], A[2]]).
A = array(X, Y, Z),
clpfd:all_distinct([X, Y]).

?- I=2, L=[X, Y, Z], L ins I-1 \/ I+1..2*I+3 \/ [-666, 42], X#>Z.
I = 2,
L = [X, Y, Z],
clpfd:(X in 1\/3..7\/42),
clpfd:(Z#=<X+ -1),
clpfd:(Y in -666\/1\/3..7\/42),
clpfd:(Z in -666\/1\/3..7).

?- array(A,[2,3],1), [X,Y] ins A[2,2]..10*A[1,1].
A = array(array(1, 1, 1), array(1, 1, 1)),
clpfd:(X in 1..10),
clpfd:(Y in 1..10).

?- array(A,[2,3],1), [X,Y] ins A[2,2]..10*A[1,1], (X-2*A[2,3])#>=Y.
A = array(array(1, 1, 1), array(1, 1, 1)),
clpfd:(X in 3..10),
clpfd:(Y#=<X+ -2),
clpfd:(Y in 1..8).
  

==


  TODO: check reification of in/2
  
    * correcting the duplication of constraint propagators upon the unification of 2 variables, e.g. in original library(clpfd)

==  
?- L=[A, B], L ins 1..2, A #=< B, bagof(W, member(W, L), L2).
L = L2, L2 = [A, B],
A in 1..2,
B#>=A,
B#>=A,
B#>=A,
B in 1..2.
==
  
That duplication of constraints was due to

    - the use of append/3 in unify_attributes_hook/2 (a.k.a. verify_attributes/2 in Scryer Prolog)

    - now replaced by union_propagators/3 

TODO: the constraint propagators should rather be simplified with respect to the unification of 2 variables X=Y
which is also a winning strategy on global constraints, compared to domain consistency only.

==
?- L=[X, Y], L ins 1..3, all_distinct(L), X=Y.
L = [Y, Y],
X = Y,
Y in 1..3,
all_distinct([Y, Y]).

?- L=[X, Y, Z], L ins 1..3, for_all(V in L, V#>1).
L = [X, Y, Z],
clpfd:(X in 2..3),
clpfd:(Y in 2..3),
clpfd:(Z in 2..3).

==

*/


				% PATCH TO CLPFD LIBRARY FOR ARRAY[INDICES] FUNCTIONAL NOTATIONS, CONSTRAINTS ON ARRAYS AND EXTRA CONSTRAINTS


% Just for pldoc 
:- op(501, xfx, ..).
:- op(502, yfx, \/).
:- op(700, xfx, in).
:- op(700, xfx, ins).


:- use_module(library(clpfd),
	      except([
		      (#>)/2,
		      (#<)/2,
		      (#>=)/2,
		      (#=<)/2,
		      (#=)/2,
		      (#\=)/2,
		      (#\)/1,
		      (#<==>)/2,
		      (#==>)/2,
		      (#<==)/2,
		      (#\/)/2,
		      (#\)/2,
		      (#/\)/2,
		      in/2,
		      ins/2,
		      all_different/1,
		      all_distinct/1,
		      sum/3,
		      scalar_product/4,
		      tuples_in/2,
		      labeling/2,
		      label/1,
		      lex_chain/1,
		      serialized/2,
		      global_cardinality/2,
		      global_cardinality/3,
		      circuit/1,
		      cumulative/1,
		      cumulative/2,
		      disjoint2/1,
		      element/3,
		      automaton/3,
		      transpose/2,
		      chain/2,
		      op(450, xfx, ..),
		      op(500, xfx, \/)
		     ]
		    )).

:- op(501, xfx, ..).
:- op(502, yfx, \/).
   
:- use_module(arrays).

:- use_module(library(clpr),
	      except([
	      	      {}/1,
	      	      entailed/1,
	      	      maximize/1,
	      	      minimize/1,
	      	      inf/2,
	      	      sup/2, 
	      	      bb_inf/3,
	      	      bb_inf/4,
	      	      bb_inf/5
	      	     ]
	      )).


				% DOMAINS


%% ?Var in +Domain
% 
% Var is in Domain with domain definitions allowing evaluable arithmetic expressions including array notations, or also lists of values as domains

Var in Domain :-
    evaluate_domain(Domain, Dom),
    expand_array_term(Var, V),
    clpfd:(V in Dom).


%% +Vars ins +Domain
% 
% Vars is in Domain possibly defined with evaluable arithmetic expressions including array notations, and also lists of values as domains

List ins Domain :-
    evaluate_domain(Domain, Dom),
    expand_array_term(List, L),
    clpfd:(L ins Dom).


evaluate_domain(Domain, Dom):-
    catch(eval_domain(Domain, Dom), Error, (writeln(error(Error)), fail))
    ->
    true
    ;
    expand_array_term(Domain, Doma),
    eval_domain(Doma, Dom).


eval_domain(Domain, Dom):-
    must_be(nonvar, Domain),
    Domain=Min..Max
    ->
    (Min = inf -> Mi = Min ; Mi is Min),
    (Max = sup -> Ma = Max ; Ma is Max),
    Dom = Mi..Ma
    ;
    Domain = (Domain1 \/ Domain2)
    ->
    eval_domain(Domain1, Dom1),
    eval_domain(Domain2, Dom2),
    Dom = (Dom1 \/ Dom2)
    ;
    is_list(Domain)
    ->
    list_to_union(Domain, Dom)
    ;
    Dom is Domain.


list_to_union([Domain], Dom):-
    !,
    eval_domain(Domain, Dom).

list_to_union([Domain | Tail], Dom\/Union):-
    eval_domain(Domain, Dom),
    list_to_union(Tail, Union).


 
				% NEW ADDED CONSTRAINTS


%! minimum(+A, ?Min)
% 
% constrains variable Min to be less or equal to all elements in array or list A

minimum(A, Min):-
    (array(A) -> array_list(A, List) ; must_be(list, A), flatten(A, List)),
    for_all(X in List, Min #=< X).


%! maximum(+A, ?Max)
% 
% constrains variable Min to be less or equal to all array cells or list elements in A

maximum(A, Max):-
    (array(A) -> array_list(A, List) ; must_be(list, A), flatten(A, List)),
    for_all(X in List, Max #>= X).


%! lex_leq(+A, +B)
%
% lexicographic ordering between arrays or lists

lex_leq(A, B):-
    (is_list(A) -> Alist=A ; array_list(A, Alist)),
    (is_list(B) -> Blist=B ; array_list(B, Blist)),
    lex_leq_list(Alist, Blist).
    

lex_leq_list([], _).
lex_leq_list([X|L], [Y|M]) :-
    X#=<Y,
    freeze(X, freeze(Y, (X==Y -> lex_leq_list(L, M) ; true))).


%! lex_lt(+A, +B)
%
% strict lexicographic ordering between arrays or lists

lex_lt(A, B):-
    (is_list(A) -> Alist=A ; array_list(A, Alist)),
    (is_list(B) -> Blist=B ; array_list(B, Blist)),
    lex_lt_list(Alist, Blist).
    

lex_lt_list([], [_ | _]).
lex_lt_list([X|L], [Y|M]) :-
    X#=<Y,
    freeze(X, freeze(Y, (X==Y -> lex_lt_list(L, M) ; true))).



				% CLPFD ARITHMETIC CONSTRAINTS


%! X #> Y
%
% constraint between expressions possibly including array cell notations

X #> Y :- eval_array_cell(X #> Y, C), clpfd:(C).                  

%! X #< Y
%
% constraint between expressions possibly including array cell notations

X #< Y :- eval_array_cell(X #< Y, C), clpfd:(C).                  

%! X #>= Y
%
% constraint between expressions possibly including array cell notations

X #>= Y :- eval_array_cell(X #>= Y, C), clpfd:(C).                   

%! X #=< Y
%
% constraint between expressions possibly including array cell notations

X #=< Y :- eval_array_cell(X #=< Y, C), clpfd:(C).                  

%! X #= Y
%
% constraint between expressions possibly including array cell notations

X #= Y :- eval_array_cell(X #= Y, C), clpfd:(C).                  

%! X #\= Y
%
% constraint between expressions possibly including array cell notations

X #\= Y :-
    eval_array_cell(X #\= Y, C),
    clpfd:(C).                  

%! #\ X
%
% negation of an expression possibly including array cell notations

#\ X :- eval_array_cell(#\ X, C), clpfd:(C).                  

%! X #<==> Y
%
% constraint between expressions possibly including array cell notations

X #<==> Y :- eval_array_cell(X #<==> Y, C), clpfd:(C).                  

%! X #==> Y
%
% constraint between expressions possibly including array cell notations

X #==> Y :- eval_array_cell(X #==> Y, C), clpfd:(C).                  

%! X #<== Y
%
% constraint between expressions possibly including array cell notations

X #<== Y :- eval_array_cell(X #<== Y, C), clpfd:(C).                  

%! X #\/ Y
%
% constraint between expressions possibly including array cell notations

X #\/ Y :- eval_array_cell(X #\/ Y, C), clpfd:(C).                  

%! X #\ Y
%
% constraint between expressions possibly including array cell notations

X #\ Y :- eval_array_cell(X #\ Y, C), clpfd:(C).                  

%! X #/\ Y
%
% constraint between expressions possibly including array cell notations

X #/\ Y :- eval_array_cell(X #/\ Y, C), clpfd:(C).                  



				% CLPFD GLOBAL CONSTRAINTS ON LISTS GENERALIZED TO ARRAYS


%! all_different(+A) 
%
% constraint on arrays similar to library(clpfd) constraint all_different on lists 

all_different(A):-
    (array(A) -> array_list(A, L) ; L=A),
    eval_array_cell(L, List),
    clpfd:all_different(List).


%! all_distinct(A)
%
% constraint on arrays or lists using library(clpfd) constraint all_distinct on list

all_distinct(A):-
    (array(A) -> array_list(A, L) ; L=A),
    eval_array_cell(L, List),
    clpfd:all_distinct(List).


%! sum(+Array, +Rel, ?Sum)
% 
% constrains variable Sum to be the sum of array values

sum(A, Rel, Sum) :-
    (array(A) -> array_list(A, L) ; L=A),
    eval_array_cell(L, List),
    clpfd:sum(List, Rel, Sum).

%! scalar_product(+A, +B, +C, ?D) 
%
% constraint on arrays similar to library(clpfd) constraint scalar_product on lists 

scalar_product(A, B, C, D) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    (array(B) -> array_list(B, BL) ; BL=B),
    eval_array_cell(AL, AList),
    eval_array_cell(BL, BList),
    clpfd:scalar_product(AList, BList, C, D).


%! lex_chain(+A) 
%
% constraint on array A similar to library(clpfd) constraint lex_chain on lists 

lex_chain(A) :-
    (array(A)
    ->
     array(A, [N | _]),
     bagof(List, I^AI^(between(1, N, I), cell(A, I, AI), array_list(AI, List)), Lists)
    ;
     Lists=A),
    eval_array_cell(Lists, L),
    clpfd:lex_chain(L).


%! tuples_in(+A, +B) 
%
% constraint on arrays A and B similar to library(clpfd) constraint tuples_in on lists 

tuples_in(A, B) :-
     (array(A) -> array_lists(A, AL) ; AL=A),
     (array(B) -> array_lists(B, BL) ; BL=B),
     eval_array_cell(AL, AList),
     eval_array_cell(BL, BList),
     clpfd:tuples_in(AList, BList).

%! serialized(+A, +B) 
%
% constraint on arrays A and B similar to library(clpfd) constraint serialized on lists 

serialized(A, B) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    (array(B) -> array_list(B, BL) ; BL=B),
    eval_array_cell(AL, AList),
    eval_array_cell(BL, BList),
    clpfd:serialized(AList, BList).

%! global_cardinality(+A, +B) 
%
% constraint on arrays A and B similar to library(clpfd) constraint global_cardinality on lists 

global_cardinality(A, B) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),    
    clpfd:global_cardinality(AList, B).

%! global_cardinality(+A, +B, +C) 
%
% constraint on arrays A, B, C similar to library(clpfd) constraint global_cardinality on lists 

global_cardinality(A, B, C) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:global_cardinality(AList, B, C).

%! circuit(+A) 
%
% constraint on array A similar to library(clpfd) constraint circuit on lists 

circuit(A) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:circuit(AList).

%! cumulative(+A) 
%
% constraint on array A similar to library(clpfd) constraint cumulative on lists 

cumulative(A) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:cumulative(AList).

%! cumulative(+A, +O) 
%
% constraint on array A with options O similar to library(clpfd) constraint cumulative on lists 

cumulative(A, B) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:cumulative(AList, B).

%! disjoint2(+A) 
%
% constraint on array A similar to library(clpfd) constraint disjoint2 on lists 

disjoint2(A) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:disjoint2(AList).

%! element(+A, +B, +C) 
%
% constraint on arrays A, B, C similar to library(clpfd) constraint element on lists 

element(A, B, C) :-
    (array(B) -> array_list(B, BL) ; BL=B),
    eval_array_cell(BL, BList),
    clpfd:element(A, BList, C).

%! automaton(+A, +B, +C) 
%
% constraint on arrays A, B, C similar to library(clpfd) constraint automaton on lists 

automaton(A, B, C) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    (array(B) -> array_list(B, BL) ; BL=B),
    (array(C) -> array_list(C, CL) ; CL=C),
    eval_array_cell(AL, AList),
    eval_array_cell(BL, BList),
    eval_array_cell(CL, CList),
    clpfd:automaton(AList, BList, CList).


%! transpose(+A, ?B) 
%
% constraint on arrays A and B similar to library(clpfd) constraint transpose on lists 

transpose(A, B) :-
    (array(A) -> array_lists(A, AL) ; AL=A),
    (array(B) -> array_lists(B, BL) ; BL=B),
    eval_array_cell(AL, AList),
    eval_array_cell(BL, BList),
    clpfd:transpose(AList, BList).

%! chain(+A, +B) 
%
% constraint on arrays A and B similar to library(clpfd) constraint chain on lists 

chain(A, B) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:chain(AList, B).



				% CLPFD ENUMERATION


%! labeling(Options, A) 
%
% value enumeration predicate on integer arrays similar to library(clpfd) labeling/2 predicate on lists 

labeling(Options, A) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:labeling(Options, AList).

%! label(A) 
%
% value enumeration predicate on arrays similar to library(clpfd) label/1 predicate on lists 

label(A) :-
    (array(A) -> array_list(A, AL) ; AL=A),
    eval_array_cell(AL, AList),
    clpfd:label(AList).

				% PATCH TO CLPFD UNIFICATION HOOK 

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   Unification hook and constraint projection
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

%foo(clpfd_attr(_,_,_,Dom,Ps), Other) :-
clpfd:attr_unify_hook(clpfd_attr(_,_,_,Dom,Ps), Other) :-
        (   nonvar(Other) ->
            (   integer(Other) -> true
            ;   type_error(integer, Other)
            ),
            clpfd:domain_contains(Dom, Other),
            clpfd:trigger_props(Ps),
            clpfd:do_queue
        ;
	    ((Ps \== fd_props([],[],[]) , get_attr(Other, clpfd, Attr))
	    ->
	     format("Warning: unifying fd_var ~w\n ~w\n with fd_var domain ~w\n constraints ~w\n", [Other, Attr, Dom, Ps])
	    ;
	     true
	    ),
	    clpfd:fd_get(Other, OD, OPs),
            clpfd:domains_intersection(OD, Dom, Dom1),
            % append_propagators(Ps, OPs, Ps1),  
	    % duplicated constraint propagators after unification, should rather simplify propagators with X=Y
	    union_propagators(Ps, OPs, Ps1),
	    % for the moment just merge propagators without duplicates, 
	    % constraint simplification would need to know the first variable as in clpz.pl not just its attributes
	    clpfd:fd_put(Other, Dom1, Ps1),
            clpfd:trigger_props(Ps1),
            clpfd:do_queue
        ).


union_propagators(fd_props(Gs0,Bs0,Os0), fd_props(Gs1,Bs1,Os1), fd_props(Gs,Bs,Os)) :-
    % sorting the propagators perturbs the queue and can cause severe performance problems
    % maplist(append, [Gs0,Bs0,Os0], [Gs1,Bs1,Os1], [Gs2,Bs2,Os2]),
    % maplist(sort(1, @<), [Gs2, Bs2, Os2], [Gs, Bs, Os]). 
    union_props(Gs0, Gs1, Gs),
    union_props(Bs0, Bs1, Bs),
    union_props(Os0, Os1, Os).


union_props([], P, P).
union_props([P | Ps0], Ps1, Ps):-
    P=propagator(Constraint, Status),
    (contains_prop(Ps1, Constraint, Status)
    ->
     union_props(Ps0, Ps1, Ps)
    ;
     Ps=[P | Pss],
     union_props(Ps0, Ps1, Pss)).

% membership check for constraint propagators
%
% TODO: add constraint simplification and disentailment check on this event of variable unification 
% e.g. disentailment of all_different all_distinct circuit disjoint2 automaton? chain
% e.g. simplification of sum scalar_product lex_chain serialized global_cardinality cumulative element automaton? transpose? chain

contains_prop([P1 | Ps1], Constraint, Status):-
    arg(1, P1, Constr),
    arg(2, P1, Stat),
    % add disentailement check and constraint simplification here
    (
     Constr==Constraint, Stat=Status % not sure about status unification
    ->
     true
    ;
     contains_prop(Ps1, Constraint, Status)).


				% CLPR

%! {+Constraint}
%
% patch of library(clpr) {}/1 predicate for allowing array notations in Constraint.

{Constraint} :- eval_array_cell(Constraint, C), clpr:{C}.                      


%! entailed(+Constraint)
%
% patch of library(clpr) entailed/1 predicate for allowing array notations in Constraint.

entailed(Constraint) :- eval_array_cell({Constraint}, C), clpr:entailed(C).

	    
%! maximize(+Expression)
%
% patch of library(clpr) maximize/1 predicate for allowing array notations in Expression.

maximize(Expression) :- eval_array_cell(Expression, E), clpr:maximize(E).

	    
%! minimize(+Expression)
%
% patch of library(clpr) minimize/1 predicate for allowing array notations in Expression.

minimize(Expression) :- eval_array_cell(Expression, E), clpr:minimize(E).


%! inf(+Expression, -Inf)
%
% patch of library(clpr) inf/2 predicate for allowing array notations in Expression.

inf(Expression, Inf) :- eval_array_cell(Expression, E), clpr:inf(E, Inf).


%! sup(+Expression, -Sup)
%
% patch of library(clpr) sup/2 predicate for allowing array notations in Expression.

sup(Expression, Sup) :- eval_array_cell(Expression, E), clpr:sup(E, Sup).


%! bb_inf(+Ints, +Expression, -Inf, -Vertex, +Eps)
%
% patch of library(clpr) bb_inf/5 predicate for allowing array notations in Expression.

bb_inf(Ints, Expression, Inf, Vertex, Eps) :- eval_array_cell(Expression, E), clpr:bb_inf(Ints, E, Inf, Vertex, Eps).


%! bb_inf(+Ints, +Expression, -Inf, -Vertex)
%
% patch of library(clpr) bb_inf/4 predicate for allowing array notations in Expression.

bb_inf(Ints, Expression, Inf, Vertex) :- eval_array_cell(Expression, E), clpr:bb_inf(Ints, E, Inf, Vertex).


%! bb_inf(+Ints, +Expression, -Inf)
%
% patch of library(clpr) bb_inf/3 predicate for allowing array notations in Expression.

bb_inf(Ints, Expression, Inf) :- eval_array_cell(Expression, E), clpr:bb_inf(Ints, E, Inf).


% %! dump(+Target, +Newvars, -CodedAnswer)
% %
% % call to library(clpr) dump/3 predicate.

% dump(Target, Newvars, CodedAnswer) :- clpr:dump(Target, Newvars, CodedAnswer).

:- reexport(library(clpfd),
	      except([
		      (#>)/2,
		      (#<)/2,
		      (#>=)/2,
		      (#=<)/2,
		      (#=)/2,
		      (#\=)/2,
		      (#\)/1,
		      (#<==>)/2,
		      (#==>)/2,
		      (#<==)/2,
		      (#\/)/2,
		      (#\)/2,
		      (#/\)/2,
		      in/2,
		      ins/2,
		      all_different/1,
		      all_distinct/1,
		      sum/3,
		      scalar_product/4,
		      tuples_in/2,
		      labeling/2,
		      label/1,
		      lex_chain/1,
		      serialized/2,
		      global_cardinality/2,
		      global_cardinality/3,
		      circuit/1,
		      cumulative/1,
		      cumulative/2,
		      disjoint2/1,
		      element/3,
		      automaton/3,
		      transpose/2,
		      chain/2,
		      op(450, xfx, ..),
		      op(500, xfx, \/)
		     ]
		    )).

:- op(501, xfx, ..).
:- op(502, yfx, \/).
   
:- reexport(arrays).

:- reexport(library(clpr),
	      except([
		      {}/1,
		      entailed/1,
		      maximize/1,
		      minimize/1,
		      inf/2,
		      sup/2, 
		      bb_inf/3,
		      bb_inf/4,
		      bb_inf/5
		     ]
		    )).
