/*
  arrays.pl
  
  @author Francois Fages
  @email Francois.Fages@inria.fr
  @license LGPL-2

  Implementation of arrays with terms using Array[Indices] notation and conversions to lists

*/

:- module(
	  arrays,
	  [
	   array/1,
	   array/2,
	   
	   cell/3,
	   cell/2,
	   op(100, yf, []),
	   
	   array_lists/2,
	   array_list/2,

	   tensor/5,
	   
	   eval_array_expr/2,
	   eval_array_cell/2,
	   expand_array_term/2,
	   expand_array_term/3,
	   
	   set_cell/3,
	   set_cell/2,
	   nb_set_cell/3,
	   nb_set_cell/2
	   ]
	 ).

/** <module> multidimensional arrays

This module provides an efficient implementation of multidimensional arrays (as array terms of array terms), indexed by integers starting at 1.

This module is compatible with attributed variables and clpfd and clpr libraries for creating arrays of constrained variables.

Array cells are accessed by unification with predicate cell/3.
Array notation Array[Indices] is allowed in constraints defined in module clp and in let expressions defined module quantifiers.

Array cells can also be modified by (backtrackable or not) destructive assignment.
  
==

?- array(A, [2,3]), cell(A, [2,2], 3).
A = array(array(_, _, _), array(_, 3, _)).

?- array(A, [2,3]), cell(A, [2], X).
A = array(array(_, _, _), array(_A, _B, _C)),
X = array(_A, _B, _C).

?- array(A, [2,3]), set_cell(A, [2], 3).
A = array(array(_, _, _), array(3, 3, 3)).

?- use_module(clp).
True.

?- array(A, [3,3]), for_all([I, J] where (I #>= J, between(1, 3, I), between(1, 3, J)), exists([C], (cell(A, [I,J], C), C #= I+J))).
A = array(array(2, _, _), array(3, 4, _), array(4, 5, 6)).


==

*/

:- use_module(quantifiers).

				% ARRAY CREATION

%! array(+Term)
% 
% tests whether a given term is an array without checking dimension consistency.

array(Term):-
    compound(Term),
    functor(Term, array, _).



%! array(?Array, ?DimensionList)
% 
% Array is an array of dimension DimensionList.
% Either creates an array of given dimensions (given by evaluable expressions), or returns the dimensions of a given array.

array(Array, Dimensions):-
    (integer(Dimensions)
    ->
     array(Array, [Dimensions])
    ;
     compound(Array)
    ->
     functor(Array, array, N),
     Dimensions=[N|Tail],
     for_all(I in 1..N,
	     let([Row=Array[I]],
		 (array(Row, Tail) -> true ; Tail=[])))
    ;
     is_list(Dimensions)
    ->
     Dimensions=[N|Tail],
     functor(Array, array, N),
     (Tail=[]
     ->
      true
     ;
      for_all(I in 1..N, exists([Row], (array(Row, Tail), cell(Array, [I], Row)))))
    ;
     % last chance: evaluate an expression for the  dimension
     eval_array_expr(Dimensions, Dim), 
     array(Array, Dim)).


array_for_all(Array, Dimensions):-
    (integer(Dimensions)
    ->
     array(Array, [Dimensions])
    ;
     compound(Array)
    ->
     functor(Array, array, N),
     for_all(I in 1..N,
	     let([Row=Array[I]],
		 (array(Row, Tail) -> true ; Tail=[]))),
     Dimensions=[N|Tail]
    ;
     is_list(Dimensions)
    ->
     Dimensions=[N|Tail],
     functor(Array, array, N),
     (Tail=[]
     ->
      true
     ;
      for_all(I in 1..N, exists([Row], (array(Row, Tail), cell(Array, [I], Row)))))
    ;
     % last chance: evaluate an expression for the  dimension
     eval_array_expr(Dimensions, Dim), 
     array(Array, Dim)).


				% CELL ACCESS
    
    
%! cell(+Array, +Indices, ?Cell)
% 
% Cell is the Array cell at given Indices (list of evaluable integer arithmetic expressions, or single evaluable expression).
% Throws an error if the indices are out of range of the array.

cell(Array, I, _Term):-
    must_be(compound, Array),
    must_be(nonvar, I),
    fail.

cell(Array, I, Term):-
    integer(I),
    !,
    functor(Array, array, N), % TODO (or not) eval Array expr
    (1=<I, I=<N
    ->
     arg(I, Array, Term)
    ;
     throw(error(index_out_of_range(cell, cell(Array, I))))).

cell(Array, [I], Term):-
    !,
    cell(Array, I, Term).

cell(Array, [I | Indices], Term):-
    !,
    cell(Array, I, Row),
    cell(Row, Indices, Term).

cell(Array, Expr, Term):-
    eval_array_expr(Expr, I),
    cell(Array, I, Term).


%! cell(+ArrayIndices, ?Cell)
% 
% Just a shorthand for cell(Array, Indices, Cell) where ArrayIndices is of the form Array[Indices]
cell(ArrayIndices, Cell):-
    must_be(nonvar, ArrayIndices),
    ArrayIndices=Array[Indices],
    cell(Array, Indices, Cell).


				% CONVERSIONS BETWEEN ARRAYS AND LISTS

%! array_list(+Array, ?List)
% 
% List is the flat list of the array cells with lexicographically ordered indices.
% For a one dimensional array, there is no difference with array_lists.

array_list(Array, List):-
    (
     array(Array)
    ->
     array_to_lists(Array, Lists),
     flatten(Lists, List)
    ;
     Array =.. [array | List]
    ).


%! array_lists(+Array, ?List)
% 
% List is the list (of lists in the case of a multidimensional array) of the array cells with lexicographically ordered indices.
% For a one dimensional array, there is no difference with array_list/2.

array_lists(Array, Lists):-
    (
     array(Array)
    ->
     array_to_lists(Array, Lists)
    ;
     lists_to_array(Lists, Array)
    ).


array_to_lists(Array, List):-
    Array =.. [array | Rows],
    (
     (Rows=[R | _], array(R))
    ->
     call_list(arrays:array_to_lists, Rows, List)
    ;
     List=Rows
    ).

lists_to_array(Lists, Array):-
    must_be(list, Lists),
    length(Lists, N),
    array(Array, N),
    for_all(I in 1..N,
	    exists([Row, L],
		   (cell(Array, [I], Row), nth1(I, Lists, L), (is_list(L) -> arrays:lists_to_array(L, Row) ; L=Row))
		  )
	   ).

				% CELL WISE TENSOR OPERATIONS


%! tensor(+A, +Op, +B, +Rel, ?C)
%
% equivalent to (A Op B) Rel C, where A, B, C are arrays or lists of same dimensions, Op is a binary operation executed element-wise, and Rel a binary predicate.
% If the argument C is a variable, the result will be an array if A or B is an array.

tensor(A, Op, B, Rel, C):-
    (array(A) ->  array_lists(A, Alist) ; Alist=A),
    (array(B) ->  array_lists(B, Blist) ; Blist=B),
    (array(C) ->  array_lists(C, Clist) ; is_list(C) -> Clist=C ; Clist=_),
    tensor_list(Alist, Op, Blist, Rel, Clist),
    ((is_list(C) ; (is_list(A), is_list(B)))
    ->
     C=Clist
    ;
     array_lists(C, Clist)).


tensor_list([], _Op, [], _Rel, []).

tensor_list([AI | A], Op, [BI | B], Rel, [CI | C]):-
    (is_list(AI), length(AI, M), length(BI, M), length(CI, M)
    ->
     tensor(AI, Op, BI, Rel, CI)
    ;
     Term =.. [Op, AI, BI], % TODO generalize to clpr constraint
     call(Rel, Term, CI)
    ),
    tensor_list(A, Op, B, Rel, C).


				% IMPERATIVE CELL ASSIGNMENT


%! set_cell(+Array, ?Term)
% 
% backtrackable assignment of Term to all array cells

set_cell(Array, Term):-
    (
     compound(Array),
     functor(Array, array, N)
    ->
     for_all([I in 1..N], set_cell(Array, I, Term))
    ;
     true
    ).


%! set_cell(+Array, +Indices, ?Term)
% 
% backtrackable assignment of Term to either simple array cell or all subarray cells, at given Indices (list of evaluable integer expressions).

set_cell(Array, [I], Term):-
    !,
    set_cell(Array, I, Term).

set_cell(Array, [I | Indices], Term):-
    !,
    cell(Array, I, Row),
    set_cell(Row, Indices, Term).

set_cell(Array, I, Term):-
    integer(I),
    !,
    cell(Array, I, Row),
    (
     array(Row)
    ->
     set_cell(Row, Term)
    ;
     setarg(I, Array, Term)
    ).


%! nb_set_cell(+Array, ?Term)
% 
% non-backtrackable assignment of Term to all array cells

nb_set_cell(Array, Term):-
    (
     compound(Array),
     functor(Array, array, N)
    ->
     for_all([I in 1..N], nb_set_cell(Array, I, Term))
    ;
     true
    ).


%! nb_set_cell(+Array, +IntegerList, ?Term)
% 
% non-backtrackable assignment of Term to either simple array cell or all subarray cells, at given indices (list of integers or integer)

nb_set_cell(Array, [I], Term):-
    !,
    nb_set_cell(Array, I, Term).

nb_set_cell(Array, [I | Indices], Term):-
    !,
    cell(Array, I, Row),
    nb_set_cell(Row, Indices, Term).

nb_set_cell(Array, I, Term):-
    integer(I),
    !,
    cell(Array, I, Row),
    (
     array(Row)
    ->
     nb_set_cell(Row, Term)
    ;
     nb_setarg(I, Array, Term)
    ).



				% EVALUATION OF ARITHMETIC EXPRESSIONS WITH ARRAY NOTATIONS


:- multifile quantifiers:expand_term/2.

quantifiers:expand_term(Term, Expanded):-
    expand_array_term(Term, Expanded),
    !.

% Unification with the result of cell/3 which is assumed to be executed before

attr_unify_hook(cell(_A, _I, X), Y):-
    %writeln(unifying(cell(A, I, X), Y)),
    X=Y.


%! eval_array_expr(+Expr, ?Term)
%
% Evaluation of ground arithmetic expressions including cell array notations of the form Array[Indices]

eval_array_expr(Expr, Num):-
    catch(Num is Expr, _, fail)
    ->
    true
    ;
    eval_array_cell(Expr, Exp),
    Num is Exp.


%! eval_array_cell(+Expr, ?Term)
%
% Term is Expr in which array cell notations of the form Array[Indices] are evaluated by cell/3 and replaced by their value

eval_array_cell(Expr, Term):-
    ((number(Expr); var(Expr))
    ->
     Term=Expr
    ;
     Expr=..[F | Tail],
     (F=[] % array cell notation
     ->
      (Tail=[]
      ->
       Term=[]
      ;
       Tail=[Indices, Array],
       call_list(eval_array_cell, Indices, Ind),
       cell(Array, Ind, Term))
     ;
      F='[|]' % list
     ->
      Tail=[Exp, Lis],
      eval_array_cell(Exp, Ex),
      eval_array_cell(Lis, Li),
      Term=[Ex | Li]
     ;
      call_list(eval_array_cell, Tail, Args),
      Term=..[F | Args])).


%! expand_array_term(+Expr, ?Term)
%
% Term is Expr in which array cell notations of the form Array[Indices] are unified with the result of cell/3

expand_array_term(Expr, Term):-
    expand_array_term(Expr, Term, AttVars),
    call_attrs(AttVars).


call_attrs([]).
call_attrs([Var | Tail]):-
    (get_attr(Var, arrays, Goal)
    ->
     call(Goal)
    ;
     true),
    call_attrs(Tail).


%! expand_array_term(+Expr, ?Term, ?AttVars)
%
% Term is Expr in which array cell accesses of the form Array[Indices] are replaced by attributed variables AttVars with cell/3 goals.

expand_array_term(Expr, Term, AttVars):-
    (compound(Expr)
    ->
     Expr=..[F | Tail],
     (F=[]			% [] or array cell notation
     ->
      (Tail=[]
      ->
       Term=[], AttVars=[]
      ;
       Tail=[Indices, Array],

       call_list(expand_array_term, Indices, Ind),
% TODO expand Array for using array of arrays notations ? 
       AttVars=[Term],
       put_attr(Term, arrays, cell(Array, Ind, Term)))
     ;
      F='[|]'			% list
     ->
      Tail=[Exp, Lis],
      expand_array_term(Exp, Ex, VarExp),
      expand_array_term(Lis, Li, VarLis),
      Term=[Ex | Li],
      append(VarExp, VarLis, AttVars)
     ;
      call_list(expand_array_term, Tail, Args, List),
      flatten(List, AttVars), 
      Term=..[F | Args])
    ;
     Term=Expr,
     AttVars=[]). 


				% REEXPORTS AT THE END FOR PLDOC

:- reexport(quantifiers).
